package edu.monmouth.cs176.s1125739.lab05;
import java.util.*;

public class Course
{
	ArrayList< Course > courses;
	 
	private String courseCode;
	private String courseNumber;
	private String courseDescription;
	
	Course ( String code, String number, String description)
	{
		this.courseCode = code;
		this.courseNumber = number;
		this.courseDescription = description;
		
		
	}
	
	public String toString()
	{
		return
				"Course: " + this.courseCode + 
				this.courseNumber + "\n" + 
				"Decription: " + this.courseDescription;
	}
	
	
	

	
}
