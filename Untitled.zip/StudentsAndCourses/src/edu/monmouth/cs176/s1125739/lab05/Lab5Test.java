package edu.monmouth.cs176.s1125739.lab05;
import java.util.*;



public class Lab5Test
{
	public static void main(String [] args)
	{
		
		
		StudentList cs176List = new StudentList();
		StudentList courses = new StudentList();
		
		
		
		
		Student s1 = new Student ("Ahmed, Saahill", "1219200", "s1219200@monmouth.edu", "CS", 2, "E.Cesario", 1.0,2022, null );
		Student s2 = new Student ("Berardis, Anthony William", "1297598", "s1297598@monmouth.edu", "CS", 2, "R.Scherl", 1.0, 2022, null );
		Student s3 = new Student ("Clappsy, Thomas V", "1218375", "s1218375@monmouth.edu", "CS",02, "J. Kretsch", 1.0, 2022, null );
		Student s4 = new Student ("Coyle, Shannon Kathryn","1226097", "s1226097@monmouth.edu","SE", 02, "J.Kretsch", 1.0, 2022, null );
		
		Course c1 = new Course ("CS", "175", "Intro to Computers");
		Course c2 = new Course ("CS", "176" , " Intro to Computers II");
		Course c3 = new Course ("CS", "205", " Data Structures & Algoroithms");
		Course c4 = new Course ("SE" , " 207", "Design Patterns & Architeture");
		
		
		cs176List.addStudent(s1);
		cs176List.addStudent(s2);
		cs176List.addStudent(s3);
		cs176List.addStudent(s4);
		
		s1.addCourse(c1);
		s1.addCourse(c2);
		s2.addCourse(c4);
		s3.addCourse(c3);
		s3.addCourse(c1);
		s4.addCourse(c2);
		
		
		cs176List.listStudents();
		
		

		
		
	
	
	}
	
}